from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    linux_commands = {
        'Navigation': {
            'ls': {
                'description': 'Shows what files and folders are in your current location',
                'example': 'ls\nfile1.txt  file2.txt  folder1/'
            },
            'cd': {
                'description': 'Moves you into a different folder',
                'example': 'cd Documents\n~/Documents $'
            },
            'pwd': {
                'description': 'Shows where you are in the computer',
                'example': 'pwd\n/home/username/Documents'
            }
        },
        'File Management': {
            'mkdir': {
                'description': 'Creates a new folder',
                'example': 'mkdir my_folder\nCreated directory: my_folder'
            },
            'rm': {
                'description': 'Deletes a file',
                'example': 'rm file.txt\nfile.txt has been removed'
            },
            'cp': {
                'description': 'Makes a copy of a file',
                'example': 'cp original.txt copy.txt\nResult: Creates copy.txt with same contents as original.txt'
            },
            'mv': {
                'description': 'Moves or renames a file',
                'example': 'mv old.txt new.txt\nResult: Renames old.txt to new.txt'
            }
        },
        'File Content': {
            'cat': {
                'description': 'Shows what is inside a file',
                'example': 'cat file.txt\nOutput: Shows all content of file.txt'
            },
            'grep': {
                'description': 'Helps you find specific text',
                'example': 'grep "hello" file.txt\nOutput: Shows lines containing "hello"'
            },
            'chmod': {
                'description': 'Changes who can use or edit a file',
                'example': 'chmod 755 script.sh\nResult: Makes script.sh executable'
            }
        }
    }
    return render_template('home.html', categories=linux_commands)

if __name__ == '__main__':
    app.run(debug=True, port=5001)